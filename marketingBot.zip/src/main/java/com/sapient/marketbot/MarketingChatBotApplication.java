package com.sapient.marketbot;

import com.sapient.marketbot.resources.ChatResource;
import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;

import javax.ws.rs.Path;
import java.util.Map;

public class MarketingChatBotApplication extends Application<MarketingChatBotConfiguration> {

    public static void main(final String[] args) throws Exception {
        new MarketingChatBotApplication().run(args);
    }

    @Override
    public String getName() {
        return "MarketingChatBotApplication";
    }

    @Override
    public void initialize(final Bootstrap<MarketingChatBotConfiguration> bootstrap) {
        // TODO: application initialization
    }

    @Override
    public void run(final MarketingChatBotConfiguration configuration,
                    final Environment environment) {
        final ChatResource resource = new ChatResource();
        environment.jersey().register(resource);
    }

}
